
let numDias = 19;

window.onload = function() {

    fillTable();
    diasSetter();
    // colspanSetter();
    fillDiagrama();
}

function fillTable() {

    let table = document.getElementById("tbodyRFTP");
    let RFTPstring = "R1 - Gestión de profesores\n" +
        "    R1F1 - Gestión de perfiles de profesores\n" +
        "        R1F1T1 - Diseñar y desarrollar la interfaz y funcionalidades para crear, modificar, eliminar y visualizar perfiles de profesores - 4 horas - 01/04/2023 - 16/03/2023 - 0%\n" +
        "        R1F1T2 - Implementar almacenamiento y gestión de datos de profesores en la base de datos - 1 horas - 17/03/2023 - 20/03/2023 - 0%\n" +
        "    R1F2 - Gestión de asignación de asignaturas a profesores\n" +
        "        R1F2T1 - Diseñar y desarrollar la interfaz y funcionalidades para asignar, modificar, eliminar y visualizar asignaturas asignadas a profesores - 4 horas - 21/03/2023 - 24/03/2023 - 0%\n" +
        "        R1F2T2 - Implementar almacenamiento y gestión de datos de asignaturas asignadas a profesores en la base de datos - 1 horas - 25/03/2023 - 27/03/2023 - 0%\n" +
        "    R1F3 - Estadísticas de profesores e institución\n" +
        "        R1F3T1 - Diseñar y desarrollar la interfaz y funcionalidades para visualizar estadísticas de profesores e institución - 4 horas - 28/03/2023 - 31/03/2023 - 0%\n" +
        "        R1F3T2 - Implementar el cálculo y presentación de estadísticas de profesores e institución en general - 2 horas - 01/04/2023 - 03/04/2023 - 0%\n" +
        "    R1F4 - Registro de notas de alumnos en asignaturas\n" +
        "        R1F4T1 - Diseñar y desarrollar la interfaz y funcionalidades para el registro de notas de alumnos en sus respectivas asignaturas - 4 horas - 04/04/2023 - 07/04/2023 - 0%\n" +
        "R2 - Gestión de alumnos\n" +
        "    R2F1 - Gestión de perfiles de alumnos\n" +
        "        R2F1T1 - Diseñar y desarrollar funcionalidades para crear perfiles de alumnos con información personal - 3 horas - 08/04/2023 - 11/04/2023 - 0%\n" +
        "    R2F2 - Asignación de alumnos a clases\n" +
        "        R2F2T1 - Diseñar y desarrollar funcionalidades para asignar alumnos a sus respectivas clases - 2 horas - 12/04/2023 - 14/04/2023 - 0%\n" +
        "    R2F3 - Estadísticas y registros de notas de alumnos\n" +
        "        R2F3T1 - Diseñar y desarrollar funcionalidades para visualizar estadísticas y registros de notas de cada alumno - 3 horas - 15/04/2023 - 18/04/2023 - 0%\n" +
        "R3 - Registro de notas\n" +
        "    R3F3 - Visualización de notas y estadísticas de alumnos por asignatura\n" +
        "        R3F3T1 - Diseñar y desarrollar funcionalidades para visualizar notas y estadísticas de alumnos por asignatura - 2 horas - 26/04/2023 - 29/04/2023 - 0%\n" +
        "    R3F4 - Ingreso y modificación de notas de alumnos en asignaturas\n" +
        "        R3F4T1 - Diseñar y desarrollar funcionalidades para ingresar y modificar notas de alumnos en sus respectivas asignaturas - 2 horas - 30/04/2023 - 03/05/2023 - 0%\n" +
        "R4 - Gestión de asignaturas\n" +
        "    R4F1 - Creación, modificación y eliminación de asignaturas\n" +
        "        R4F1T1 - Diseñar y desarrollar funcionalidades para crear, modificar y eliminar asignaturas - 3 horas - 04/05/2023 - 06/05/2023 - 0%\n" +
        "    R4F2 - Asignación de profesores a asignaturas\n" +
        "        R4F2T1 - Diseñar y desarrollar funcionalidades para asignar profesores a sus respectivas asignaturas - 3 horas - 07/05/2023 - 09/05/2023 - 0%\n" +
        "    R4F3 - Estadísticas y registros de notas de asignaturas\n" +
        "        R4F3T1 - Diseñar y desarrollar funcionalidades para visualizar estadísticas y registros de notas de cada asignatura - 2 horas - 10/05/2023 - 13/05/2023 - 0%\n" +
        "R5 - Gestión de usuarios y autenticación\n" +
        "    R5F1 - Registro de usuarios y contraseñas\n" +
        "        R5F1T1 - Diseñar y desarrollar funcionalidades para registrar usuarios y contraseñas en el sistema - 2 horas - 14/05/2023 - 15/05/2023 - 0%\n" +
        "    R5F2 - Autenticación y autorización\n" +
        "        R5F2T1 - Diseñar e implementar funcionalidades para autenticar y autorizar usuarios según sus roles - 3 horas - 16/05/2023 - 18/05/2023 - 0%\n" +
        "    R5F3 - Recuperación de contraseñas\n" +
        "        R5F3T1 - Diseñar y desarrollar funcionalidades para la recuperación de contraseñas - 1 horas - 19/05/2023 - 20/05/2023 - 0%\n" +
        "R6 - Integración y pruebas\n" +
        "    R6F1 - Integración de componentes y módulos\n" +
        "        R6F1T1 - Integrar los componentes y módulos del sistema para asegurar su correcto funcionamiento conjunto - 4 horas - 21/05/2023 - 24/05/2023 - 0%\n" +
        "    R6F2 - Pruebas de funcionalidad\n" +
        "        R6F2T1 - Realizar pruebas de funcionalidad para identificar y solucionar posibles problemas en el sistema - 4 horas - 25/05/2023 - 28/05/2023 - 0%\n" +
        "    R6F3 - Pruebas de rendimiento y seguridad\n" +
        "        R6F3T1 - Realizar pruebas de rendimiento y seguridad para garantizar un sistema estable y seguro - 2 horas - 29/05/2023 - 31/05/2023 - 0%\n" +
        "R7 - Implementación y despliegue\n" +
        "    R7F1 - Configuración del entorno de producción\n" +
        "        R7F1T1 - Configurar el entorno de producción para desplegar el sistema - 2 horas - 01/06/2023 - 02/06/2023 - 0%\n" +
        "    R7F2 - Despliegue del sistema\n" +
        "        R7F2T1 - Desplegar el sistema en el entorno de producción - 1 horas - 03/06/2023 - 03/06/2023 - 0%\n" +
        "R8 - Mantenimiento y actualizaciones\n" +
        "    R8F1 - Monitoreo del sistema y resolución de problemas\n" +
        "        R8F1T1 - Monitorear el sistema y resolver problemas identificados en producción - 4 horas - 07/06/2023 - 13/06/2023 - 0%\n" +
        "    R8F2 - Actualizaciones y mejoras\n" +
        "        R8F2T1 - Implementar actualizaciones y mejoras al sistema según necesidades identificadas - 8 horas - 14/06/2023 - 20/06/2023 - 0%\n";

    let listadoHTML = '';
    let listado = RFTPstring.split("\n");

    for (let i = 0; i < listado.length; i++) {
        let tarea = listado[i];
        let split = tarea.split("-");
        let Thirtyspaces = "";

        for (let j = 0; j < numDias; j++) {
            Thirtyspaces += '<td onclick="changeBG()" class="' + i + ' square" ></td>';
        }

        switch (split[0].length) {
            case 3:
                listadoHTML += "<tr class='tableBorder'><!-- <td>" + i + "</td>--> <td>" + split[1] + "</td><td></td><td></td><td></td>";
                listadoHTML += Thirtyspaces;
                listadoHTML += "</tr>";

                break;
            case 15:
                let duracion = split[2].split(" ");
                listadoHTML += "<tr><!-- <td>" + i + "</td> --><td></td><td>" + split[1] + "</td><td class='hora flex flex-center'>" + duracion[1] + "</td><td>" + split[5] + "</td>";
                listadoHTML += Thirtyspaces;
                listadoHTML += "</tr>";
                break;

        }
    }

    table.innerHTML = listadoHTML;

    sumHoras();


}
function changeBG() {
    let td = document.getElementsByTagName("td");
    for (let i = 0; i < td.length; i++) {
        td[i].addEventListener("click", function () {
            td[i].style.backgroundColor = "red";
        });
    }
}

function diasSetter() {
    let dias = document.getElementById("theadSuperior");
    let listaDias = `<tr>
        <!--
        <th>Nª</th>
        -->
        <th>Requisito</th>
        <th>Tarea</th>
        <th>Horas</th>
        <th>&nbsp;&nbsp;%&nbsp;&nbsp;</th>
    `;
    for (let i = 0; i < numDias; i++) {
        listaDias += '<th>' + (i + 1) + '</th>';
    }

    listaDias += '</tr>';
    dias.innerHTML = listaDias;

}

function colspanSetter() {
    let diagrama = document.getElementById("diagrama");
    diagrama.setAttribute("rowspan", "25");

    diagrama.innerHTML = "Diagrama de Gantt";

}


function fillDiagrama() {
    document.getElementsByClassName("2")[0].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("3")[1].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("5")[0].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("5")[1].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("6")[2].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("8")[3].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("9")[3].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("11")[4].style.backgroundColor = "#C5A3FF";

    document.getElementsByClassName("14")[5].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("14")[6].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("16")[6].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("18")[6].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("18")[7].style.backgroundColor = "#C5A3FF";

    document.getElementsByClassName("21")[9].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("23")[9].style.backgroundColor = "#C5A3FF";

    document.getElementsByClassName("26")[10].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("26")[11].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("28")[11].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("30")[13].style.backgroundColor = "#C5A3FF";

    document.getElementsByClassName("33")[12].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("35")[12].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("37")[13].style.backgroundColor = "#C5A3FF";

    document.getElementsByClassName("40")[13].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("42")[14].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("44")[14].style.backgroundColor = "#C5A3FF";

    document.getElementsByClassName("47")[15].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("49")[15].style.backgroundColor = "#C5A3FF";

    document.getElementsByClassName("52")[16].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("54")[16].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("54")[17].style.backgroundColor = "#C5A3FF";
    document.getElementsByClassName("54")[18].style.backgroundColor = "#C5A3FF";



}

function sumHoras() {
    let horas = document.getElementsByClassName("hora");
    let suma = 0;
    for (let i = 0; i < horas.length; i++) {
        suma += parseInt(horas[i].innerHTML);
    }

    let totalHoras = document.getElementById("totalHoras");
    totalHoras.innerHTML = suma;
}



